
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Plus, Minus, Edit, Trash2 } from "lucide-react";
import { motion } from 'framer-motion';

export interface Item {
  id: string;
  name: string;
  price: number;
  category: string;
  image?: string;
}

interface ItemCardProps {
  item: Item;
  onAdd: (item: Item) => void;
  onRemove: (id: string) => void;
  onEdit: (item: Item) => void;
  quantity: number;
}

const ItemCard: React.FC<ItemCardProps> = ({ 
  item, 
  onAdd, 
  onRemove, 
  onEdit,
  quantity 
}) => {
  const [isHovered, setIsHovered] = useState(false);
  
  const placeholderImage = `https://source.unsplash.com/300x300/?food-${item.name.replace(/\s+/g, '-')}`;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.2 }}
      whileHover={{ y: -3 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      layout
    >
      <Card className="overflow-hidden border shadow-soft bg-white transition-all duration-300 h-full flex flex-col">
        <div 
          className="aspect-square relative overflow-hidden bg-pos"
          style={{ perspective: '1000px' }}
        >
          <img
            src={item.image || placeholderImage}
            alt={item.name}
            className="h-full w-full object-cover transition-all duration-500"
            style={{
              transform: isHovered ? 'scale(1.05)' : 'scale(1)',
            }}
            loading="lazy"
          />
          
          {/* Admin controls - show on hover */}
          <div 
            className={`absolute inset-0 bg-black/40 backdrop-blur-[2px] flex items-center justify-center gap-2 transition-opacity duration-300 ${
              isHovered ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <Button 
              variant="outline" 
              size="icon" 
              className="rounded-full h-9 w-9 bg-white hover:bg-white/90 text-pos-dark"
              onClick={() => onEdit(item)}
            >
              <Edit size={16} />
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className="rounded-full h-9 w-9 bg-white hover:bg-white/90 text-pos-error hover:text-pos-error"
              onClick={() => onRemove(item.id)}
            >
              <Trash2 size={16} />
            </Button>
          </div>
        </div>
        
        <CardContent className="p-4 flex-1 flex flex-col">
          <div className="mb-1">
            <div className="text-xs text-pos-text-secondary font-medium uppercase tracking-wide opacity-70">
              {item.category}
            </div>
            <h3 className="font-medium text-pos-dark mt-0.5">{item.name}</h3>
          </div>
          <div className="mt-auto">
            <div className="font-semibold text-pos-dark">
              ${item.price.toFixed(2)}
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="p-4 pt-0 flex items-center justify-between gap-1">
          <div className="flex items-center h-8 border rounded-md overflow-hidden">
            <Button 
              variant="ghost" 
              size="icon" 
              className={`h-full w-8 rounded-none p-0 ${quantity === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
              onClick={() => quantity > 0 && onRemove(item.id)}
              disabled={quantity === 0}
            >
              <Minus size={14} />
            </Button>
            <div className="w-8 h-full flex items-center justify-center text-sm font-medium">
              {quantity}
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-full w-8 rounded-none p-0"
              onClick={() => onAdd(item)}
            >
              <Plus size={14} />
            </Button>
          </div>
          
          <Button 
            variant="default" 
            size="sm" 
            className="h-8 bg-pos-accent hover:bg-pos-accent-hover text-white"
            onClick={() => onAdd(item)}
          >
            Add
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default ItemCard;
