
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserCircle, ShieldCheck } from "lucide-react";

type LoginScreenProps = {
  onLogin: (role: 'admin' | 'staff') => void;
};

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [role, setRole] = useState<'admin' | 'staff'>('admin');
  const { toast } = useToast();

  // Subtle animation for the background elements
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate network request
    setTimeout(() => {
      if (role === 'admin' && username === 'ProjectPOS' && password === 'Restaurant') {
        toast({
          title: "Admin login successful",
          description: "Welcome to Restaurant POS System",
        });
        onLogin('admin');
      } else if (role === 'staff' && username === 'stafflogin' && password === 'staff') {
        toast({
          title: "Staff login successful",
          description: "Welcome to Restaurant POS System",
        });
        onLogin('staff');
      } else {
        toast({
          variant: "destructive",
          title: "Login failed",
          description: "Invalid username or password. Please try again.",
        });
      }
      setIsLoading(false);
    }, 800);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-pos p-4 relative overflow-hidden">
      {/* Dynamic background elements */}
      <div 
        className="absolute w-[500px] h-[500px] rounded-full bg-blue-100/30 blur-3xl" 
        style={{ 
          left: mousePosition.x * 0.05, 
          top: mousePosition.y * 0.05 
        }}
      />
      <div 
        className="absolute w-[300px] h-[300px] rounded-full bg-indigo-100/20 blur-3xl" 
        style={{ 
          right: mousePosition.x * 0.02, 
          bottom: mousePosition.y * 0.02 
        }}
      />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="w-full max-w-md z-10"
      >
        <Card className="glassmorphism border-none shadow-medium">
          <CardHeader className="space-y-2 text-center">
            <CardTitle className="text-3xl font-semibold tracking-tight text-pos-dark">
              Restaurant POS System
            </CardTitle>
            <CardDescription className="text-pos-text-secondary">
              Enter your credentials to access the system
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="admin" value={role} onValueChange={(value) => setRole(value as 'admin' | 'staff')} className="w-full mb-6">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="admin" className="flex items-center justify-center gap-2">
                  <ShieldCheck className="h-4 w-4" />
                  <span>Admin</span>
                </TabsTrigger>
                <TabsTrigger value="staff" className="flex items-center justify-center gap-2">
                  <UserCircle className="h-4 w-4" />
                  <span>Staff</span>
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-sm font-medium">
                  Username
                </Label>
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="h-11 bg-white/60 focus:bg-white/90 transition-colors"
                  placeholder="Enter username"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium">
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11 bg-white/60 focus:bg-white/90 transition-colors"
                  placeholder="Enter password"
                  required
                />
              </div>
              <Button 
                type="submit" 
                className="w-full h-11 mt-6 bg-pos-accent hover:bg-pos-accent-hover transition-all duration-300 text-white font-medium"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center">
                    <svg className="animate-spin -ml-1 mr-3 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </div>
                ) : "Sign In"}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="justify-center pt-0">
            <div className="text-xs text-pos-text-secondary mt-4">
              <div className="opacity-50 mb-1">Login details:</div>
              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="bg-pos/50 p-2 rounded">
                  <div className="font-medium">Admin</div>
                  <div>Username: ProjectPOS</div>
                  <div>Password: Restaurant</div>
                </div>
                <div className="bg-pos/50 p-2 rounded">
                  <div className="font-medium">Staff</div>
                  <div>Username: stafflogin</div>
                  <div>Password: staff</div>
                </div>
              </div>
            </div>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
};

export default LoginScreen;
