
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogTrigger
} from "@/components/ui/dialog";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Plus, Search, Filter } from "lucide-react";
import ItemCard, { Item } from './ItemCard';
import { useToast } from "@/components/ui/use-toast";
import { motion, AnimatePresence } from 'framer-motion';

// Sample categories - these would come from a database in a real app
const categories = [
  "All",
  "Appetizers",
  "Main Course",
  "Wraps",
  "Burgers",
  "Desserts",
  "Beverages",
  "Sides"
];

// Sample initial menu items
const initialItems: Item[] = [
  {
    id: "1",
    name: "Classic Burger",
    price: 12.99,
    category: "Burgers",
    image: "https://source.unsplash.com/500x500/?burger"
  },
  {
    id: "2",
    name: "Caesar Salad",
    price: 8.99,
    category: "Appetizers",
    image: "https://source.unsplash.com/500x500/?salad"
  },
  {
    id: "3",
    name: "Chocolate Cake",
    price: 6.99,
    category: "Desserts",
    image: "https://source.unsplash.com/500x500/?chocolate-cake"
  },
  {
    id: "4",
    name: "Iced Coffee",
    price: 4.99,
    category: "Beverages",
    image: "https://source.unsplash.com/500x500/?iced-coffee"
  },
  {
    id: "5",
    name: "French Fries",
    price: 3.99,
    category: "Sides",
    image: "https://source.unsplash.com/500x500/?french-fries"
  },
  {
    id: "6",
    name: "Margherita Pizza",
    price: 14.99,
    category: "Main Course",
    image: "https://source.unsplash.com/500x500/?pizza"
  },
  {
    id: "7",
    name: "Chicken Wrap",
    price: 9.99,
    category: "Wraps",
    image: "https://source.unsplash.com/500x500/?chicken-wrap"
  },
  {
    id: "8",
    name: "Veggie Wrap",
    price: 8.99,
    category: "Wraps",
    image: "https://source.unsplash.com/500x500/?veggie-wrap"
  },
  {
    id: "9",
    name: "Double Cheese Burger",
    price: 15.99,
    category: "Burgers",
    image: "https://source.unsplash.com/500x500/?cheeseburger"
  },
  {
    id: "10",
    name: "Vegan Burger",
    price: 13.99,
    category: "Burgers",
    image: "https://source.unsplash.com/500x500/?vegan-burger"
  }
];

interface CartItem extends Item {
  quantity: number;
}

interface MenuItemsProps {
  onCheckout: (items: CartItem[], total: number) => void;
}

const MenuItems: React.FC<MenuItemsProps> = ({ onCheckout }) => {
  const [menuItems, setMenuItems] = useState<Item[]>(initialItems);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [newItem, setNewItem] = useState<Partial<Item>>({
    name: "",
    price: 0,
    category: "Main Course"
  });
  const [isEditing, setIsEditing] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  
  const { toast } = useToast();
  
  // Calculate total
  const cartTotal = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity, 
    0
  );
  
  // Filter items based on search and category
  const filteredItems = menuItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "All" || item.category === activeCategory;
    return matchesSearch && matchesCategory;
  });
  
  // Add item to cart
  const addToCart = (item: Item) => {
    setCartItems(prev => {
      const existingItem = prev.find(i => i.id === item.id);
      
      if (existingItem) {
        return prev.map(i => 
          i.id === item.id 
            ? { ...i, quantity: i.quantity + 1 } 
            : i
        );
      } else {
        return [...prev, { ...item, quantity: 1 }];
      }
    });
    
    // Show a subtle toast
    toast({
      description: `Added ${item.name} to cart`,
      duration: 1500,
    });
  };
  
  // Remove item from cart
  const removeFromCart = (id: string) => {
    setCartItems(prev => {
      const existingItem = prev.find(i => i.id === id);
      
      if (existingItem && existingItem.quantity > 1) {
        return prev.map(i => 
          i.id === id 
            ? { ...i, quantity: i.quantity - 1 } 
            : i
        );
      } else {
        return prev.filter(i => i.id !== id);
      }
    });
  };
  
  // Add new menu item
  const addMenuItem = () => {
    if (!newItem.name || !newItem.price) {
      toast({
        variant: "destructive",
        title: "Invalid item",
        description: "Please fill in all required fields."
      });
      return;
    }
    
    const id = isEditing ? (newItem.id as string) : Date.now().toString();
    const item = { ...newItem, id } as Item;
    
    if (isEditing) {
      setMenuItems(prev => prev.map(i => (i.id === id ? item : i)));
      toast({
        title: "Item updated",
        description: `${item.name} has been updated.`,
      });
    } else {
      setMenuItems(prev => [...prev, item]);
      toast({
        title: "Item added",
        description: `${item.name} has been added to the menu.`,
      });
    }
    
    // Reset form and close dialog
    setNewItem({ name: "", price: 0, category: "Main Course" });
    setIsEditing(false);
    setDialogOpen(false);
  };
  
  // Edit menu item
  const editMenuItem = (item: Item) => {
    setNewItem(item);
    setIsEditing(true);
    setDialogOpen(true);
  };
  
  // Delete menu item
  const deleteMenuItem = (id: string) => {
    setMenuItems(prev => prev.filter(item => item.id !== id));
    // Also remove from cart if present
    setCartItems(prev => prev.filter(item => item.id !== id));
    
    toast({
      title: "Item deleted",
      description: "The menu item has been removed.",
    });
  };
  
  // Get quantity of item in cart
  const getItemQuantity = (id: string): number => {
    const item = cartItems.find(i => i.id === id);
    return item ? item.quantity : 0;
  };
  
  // Handle checkout
  const handleCheckout = () => {
    if (cartItems.length === 0) {
      toast({
        variant: "destructive",
        title: "Empty cart",
        description: "Please add items to your cart before checkout."
      });
      return;
    }
    
    onCheckout(cartItems, cartTotal);
  };
  
  return (
    <div className="flex flex-col h-full">
      <div className="p-4 flex-shrink-0">
        <div className="flex flex-wrap gap-4 mb-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-pos-text-secondary pointer-events-none" />
            <Input
              placeholder="Search menu items..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 h-10 bg-white"
            />
          </div>
          
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                className="bg-pos-accent hover:bg-pos-accent-hover text-white"
                onClick={() => {
                  setNewItem({ name: "", price: 0, category: "Main Course" });
                  setIsEditing(false);
                }}
              >
                <Plus className="mr-2 h-4 w-4" /> Add Item
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>
                  {isEditing ? "Edit Menu Item" : "Add New Menu Item"}
                </DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Item Name</Label>
                  <Input
                    id="name"
                    value={newItem.name || ""}
                    onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                    placeholder="e.g. Chicken Wings"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="price">Price ($)</Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    min="0"
                    value={newItem.price || ""}
                    onChange={(e) => setNewItem({ ...newItem, price: parseFloat(e.target.value) })}
                    placeholder="0.00"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={newItem.category}
                    onValueChange={(value) => setNewItem({ ...newItem, category: value })}
                  >
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.filter(cat => cat !== "All").map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="image">Image URL (Optional)</Label>
                  <Input
                    id="image"
                    value={newItem.image || ""}
                    onChange={(e) => setNewItem({ ...newItem, image: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="submit"
                  onClick={addMenuItem}
                  className="bg-pos-accent hover:bg-pos-accent-hover text-white"
                >
                  {isEditing ? "Update" : "Add"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        
        <Tabs defaultValue="All" value={activeCategory} onValueChange={setActiveCategory}>
          <ScrollArea className="w-full whitespace-nowrap pb-2">
            <TabsList className="h-9 bg-transparent">
              {categories.map((category) => (
                <TabsTrigger 
                  key={category} 
                  value={category}
                  className="px-4 data-[state=active]:bg-pos-accent data-[state=active]:text-white relative overflow-hidden h-full"
                >
                  {category}
                </TabsTrigger>
              ))}
            </TabsList>
          </ScrollArea>
        </Tabs>
      </div>
      
      <div className="flex flex-1 min-h-0">
        <div className="flex-1 p-4 pb-0 overflow-hidden">
          <ScrollArea className="h-full pb-4">
            <motion.div 
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4"
              layout
            >
              <AnimatePresence>
                {filteredItems.map((item) => (
                  <ItemCard
                    key={item.id}
                    item={item}
                    onAdd={addToCart}
                    onRemove={removeFromCart}
                    onEdit={editMenuItem}
                    quantity={getItemQuantity(item.id)}
                  />
                ))}
              </AnimatePresence>

              {filteredItems.length === 0 && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="col-span-full flex flex-col items-center justify-center p-8 text-center"
                >
                  <div className="text-pos-text-secondary mb-2">
                    <Filter className="w-12 h-12 opacity-20 mx-auto mb-2" />
                    <h3 className="text-lg font-medium text-pos-dark">No items found</h3>
                    <p className="text-sm opacity-70 max-w-md mx-auto">
                      Try adjusting your search or filter to find what you're looking for.
                    </p>
                  </div>
                </motion.div>
              )}
            </motion.div>
          </ScrollArea>
        </div>
        
        <div className="w-[380px] border-l bg-white flex flex-col">
          <div className="p-4 border-b">
            <h2 className="font-medium text-lg">Order Summary</h2>
          </div>
          
          <ScrollArea className="flex-1">
            <div className="p-4 space-y-4">
              {cartItems.length === 0 ? (
                <div className="text-center py-8 text-pos-text-secondary">
                  <p>Your cart is empty</p>
                  <p className="text-sm mt-1 opacity-70">Add items from the menu</p>
                </div>
              ) : (
                <AnimatePresence>
                  {cartItems.map((item) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.2 }}
                      className="flex items-center justify-between py-2"
                    >
                      <div className="flex items-center space-x-2">
                        <div className="h-10 w-10 bg-pos rounded-md overflow-hidden">
                          <img
                            src={item.image || `https://source.unsplash.com/100x100/?food-${item.name.replace(/\s+/g, '-')}`}
                            alt={item.name}
                            className="h-full w-full object-cover"
                            loading="lazy"
                          />
                        </div>
                        <div>
                          <div className="font-medium text-sm">{item.name}</div>
                          <div className="text-xs text-pos-text-secondary">
                            ${item.price.toFixed(2)} × {item.quantity}
                          </div>
                        </div>
                      </div>
                      <div className="font-medium">
                        ${(item.price * item.quantity).toFixed(2)}
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              )}
            </div>
          </ScrollArea>
          
          <div className="border-t p-4">
            <div className="flex justify-between items-center mb-4">
              <span className="font-medium">Total</span>
              <span className="text-xl font-semibold">${cartTotal.toFixed(2)}</span>
            </div>
            <Button 
              className="w-full h-12 bg-pos-accent hover:bg-pos-accent-hover text-white font-medium"
              onClick={handleCheckout}
              disabled={cartItems.length === 0}
            >
              Proceed to Checkout
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MenuItems;
