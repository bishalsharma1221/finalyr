
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/components/ui/use-toast";
import { motion, AnimatePresence } from 'framer-motion';
import { CreditCard, Gift, Banknote, Check, Printer } from "lucide-react";

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  category: string;
  image?: string;
}

interface PaymentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  cartItems: CartItem[];
  total: number;
  onComplete: () => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({
  open,
  onOpenChange,
  cartItems,
  total,
  onComplete,
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'cash' | 'gift'>('card');
  const [cashAmount, setCashAmount] = useState(total.toFixed(2));
  const [giftCardNumber, setGiftCardNumber] = useState('');
  const [processing, setProcessing] = useState(false);
  const [complete, setComplete] = useState(false);
  const [receiptPrinted, setReceiptPrinted] = useState(false);
  
  const { toast } = useToast();
  
  // Calculate change for cash payment
  const change = Math.max(0, parseFloat(cashAmount) - total);
  
  // Handle payment processing
  const processPayment = () => {
    setProcessing(true);
    
    // Validate inputs based on payment method
    if (paymentMethod === 'cash') {
      if (parseFloat(cashAmount) < total) {
        toast({
          variant: "destructive",
          title: "Insufficient cash amount",
          description: "The cash amount must be equal to or greater than the total."
        });
        setProcessing(false);
        return;
      }
    } else if (paymentMethod === 'gift') {
      if (giftCardNumber.length < 8) {
        toast({
          variant: "destructive",
          title: "Invalid gift card",
          description: "Please enter a valid gift card number."
        });
        setProcessing(false);
        return;
      }
    }
    
    // Simulate payment processing
    setTimeout(() => {
      setProcessing(false);
      setComplete(true);
      
      toast({
        title: "Payment successful",
        description: `Payment of $${total.toFixed(2)} completed!`,
      });
      
      // Close modal and reset state after success animation
      setTimeout(() => {
        if (!receiptPrinted) {
          setReceiptPrinted(false);
        }
      }, 1500);
    }, 1000);
  };
  
  // Handle receipt printing
  const printReceipt = () => {
    // Create a new window for the receipt
    const printWindow = window.open('', '_blank', 'width=400,height=600');
    
    if (!printWindow) {
      toast({
        variant: "destructive",
        title: "Print Error",
        description: "Unable to open print window. Please check your popup settings."
      });
      return;
    }
    
    // Generate receipt HTML
    const receiptHTML = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Receipt</title>
        <style>
          body {
            font-family: 'Courier New', monospace;
            margin: 0;
            padding: 20px;
            max-width: 300px;
          }
          .header {
            text-align: center;
            margin-bottom: 20px;
          }
          .divider {
            border-top: 1px dashed #000;
            margin: 10px 0;
          }
          .item {
            display: flex;
            justify-content: space-between;
            margin: 5px 0;
          }
          .item-name {
            max-width: 70%;
          }
          .total {
            font-weight: bold;
            margin-top: 10px;
            text-align: right;
          }
          .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 12px;
          }
          .payment-method {
            margin-top: 15px;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h2>Restaurant POS System</h2>
          <p>${new Date().toLocaleString()}</p>
        </div>
        
        <div class="divider"></div>
        
        <div>
          ${cartItems.map(item => `
            <div class="item">
              <div class="item-name">${item.quantity}x ${item.name}</div>
              <div>$${(item.price * item.quantity).toFixed(2)}</div>
            </div>
          `).join('')}
        </div>
        
        <div class="divider"></div>
        
        <div class="total">
          <div class="item">
            <div>TOTAL:</div>
            <div>$${total.toFixed(2)}</div>
          </div>
          ${paymentMethod === 'cash' && parseFloat(cashAmount) > total ? `
            <div class="item">
              <div>CASH:</div>
              <div>$${parseFloat(cashAmount).toFixed(2)}</div>
            </div>
            <div class="item">
              <div>CHANGE:</div>
              <div>$${change.toFixed(2)}</div>
            </div>
          ` : ''}
        </div>
        
        <div class="payment-method">
          Payment Method: ${paymentMethod === 'card' ? 'Card' : paymentMethod === 'cash' ? 'Cash' : 'Gift Card'}
        </div>
        
        <div class="footer">
          <p>Thank you for your purchase!</p>
        </div>
        
        <script>
          window.onload = function() {
            window.print();
          }
        </script>
      </body>
      </html>
    `;
    
    printWindow.document.open();
    printWindow.document.write(receiptHTML);
    printWindow.document.close();
    
    setReceiptPrinted(true);
    
    toast({
      title: "Printing Receipt",
      description: "The receipt has been sent to the printer."
    });
  };
  
  // Close and reset modal
  const finishTransaction = () => {
    setPaymentMethod('card');
    setCashAmount(total.toFixed(2));
    setGiftCardNumber('');
    setComplete(false);
    setReceiptPrinted(false);
    onComplete();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] p-0 overflow-hidden flex flex-col">
        <AnimatePresence mode="wait">
          {complete ? (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex flex-col items-center justify-center p-8 text-center"
            >
              <div className="w-16 h-16 bg-pos-success/10 rounded-full flex items-center justify-center mb-4">
                <Check className="w-8 h-8 text-pos-success" />
              </div>
              <h2 className="text-2xl font-semibold mb-2">Payment Successful!</h2>
              <p className="text-pos-text-secondary mb-4">
                Your order has been processed successfully.
              </p>
              <p className="font-semibold text-lg">
                Total: ${total.toFixed(2)}
              </p>
              {paymentMethod === 'cash' && change > 0 && (
                <p className="mt-2 text-pos-text-secondary">
                  Change: ${change.toFixed(2)}
                </p>
              )}
              
              <div className="flex gap-4 mt-6">
                <Button
                  variant="outline"
                  className="flex items-center gap-2"
                  onClick={printReceipt}
                >
                  <Printer className="h-4 w-4" />
                  Print Receipt
                </Button>
                
                <Button onClick={finishTransaction}>
                  Done
                </Button>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="payment"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col h-full w-full"
            >
              <DialogHeader className="p-6 pb-2">
                <DialogTitle>Checkout</DialogTitle>
                <DialogDescription>
                  Complete your order by selecting a payment method.
                </DialogDescription>
              </DialogHeader>
              
              <div className="flex flex-col sm:flex-row flex-1 overflow-hidden">
                <div className="w-full">
                  <Tabs defaultValue="card" value={paymentMethod} onValueChange={(value) => setPaymentMethod(value as 'card' | 'cash' | 'gift')}>
                    <div className="p-6 pt-2 pb-4">
                      <TabsList className="grid grid-cols-3 mb-4">
                        <TabsTrigger value="card" className="flex items-center gap-2">
                          <CreditCard className="h-4 w-4" />
                          <span>Card</span>
                        </TabsTrigger>
                        <TabsTrigger value="cash" className="flex items-center gap-2">
                          <Banknote className="h-4 w-4" />
                          <span>Cash</span>
                        </TabsTrigger>
                        <TabsTrigger value="gift" className="flex items-center gap-2">
                          <Gift className="h-4 w-4" />
                          <span>Gift Card</span>
                        </TabsTrigger>
                      </TabsList>
                      
                      <TabsContent value="card" className="mt-0 space-y-4">
                        <div className="p-6 text-center">
                          <div className="mb-4 p-4 bg-pos rounded-md">
                            <CreditCard className="h-16 w-16 mx-auto mb-2 text-pos-accent" />
                            <p>Customer will pay using card terminal</p>
                            <p className="text-sm text-pos-text-secondary mt-1">No card details required</p>
                          </div>
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="cash" className="mt-0 space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="cash-amount">Cash Amount</Label>
                          <Input
                            id="cash-amount"
                            type="number"
                            step="0.01"
                            min={total}
                            value={cashAmount}
                            onChange={(e) => setCashAmount(e.target.value)}
                          />
                        </div>
                        {parseFloat(cashAmount) >= total && (
                          <div className="p-3 bg-pos/30 rounded-md">
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-pos-text-secondary">Change:</span>
                              <span className="font-medium">${change.toFixed(2)}</span>
                            </div>
                          </div>
                        )}
                      </TabsContent>
                      
                      <TabsContent value="gift" className="mt-0 space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="gift-card">Gift Card Number</Label>
                          <Input
                            id="gift-card"
                            placeholder="XXXX-XXXX-XXXX-XXXX"
                            value={giftCardNumber}
                            onChange={(e) => setGiftCardNumber(e.target.value)}
                          />
                        </div>
                      </TabsContent>
                    </div>
                  </Tabs>
                  
                  <div className="px-6 pb-6">
                    <Separator className="mb-4" />
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Subtotal:</span>
                        <span>${total.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Tax:</span>
                        <span>$0.00</span>
                      </div>
                      <div className="flex justify-between items-center font-medium">
                        <span>Total:</span>
                        <span className="text-lg">${total.toFixed(2)}</span>
                      </div>
                    </div>
                    
                    <Button 
                      className="w-full h-10 mt-4 bg-pos-accent hover:bg-pos-accent-hover text-white"
                      onClick={processPayment}
                      disabled={processing}
                    >
                      {processing ? (
                        <div className="flex items-center">
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Processing...
                        </div>
                      ) : "Complete Payment"}
                    </Button>
                  </div>
                </div>
                
                <div className="border-t sm:border-l sm:border-t-0 sm:w-[260px] bg-pos/30">
                  <div className="p-4 border-b">
                    <h3 className="font-medium">Order Summary</h3>
                  </div>
                  
                  <ScrollArea className="h-[250px]">
                    <div className="p-4 space-y-2">
                      {cartItems.map((item) => (
                        <div key={item.id} className="flex justify-between text-sm">
                          <span className="text-pos-text-secondary">
                            {item.quantity}× {item.name}
                          </span>
                          <span className="font-medium">
                            ${(item.price * item.quantity).toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
};

export default PaymentModal;
