
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import MenuItems from './MenuItems';
import PaymentModal from './PaymentModal';
import { useToast } from "@/components/ui/use-toast";
import { motion } from 'framer-motion';
import { User, LogOut, Home, ChefHat, Clock, BarChart, Settings, ShieldCheck } from 'lucide-react';

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  category: string;
  image?: string;
}

interface DashboardProps {
  onLogout: () => void;
  userRole: 'admin' | 'staff';
}

const Dashboard: React.FC<DashboardProps> = ({ onLogout, userRole }) => {
  const [activeTab, setActiveTab] = useState("menu");
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartTotal, setCartTotal] = useState(0);
  
  const { toast } = useToast();
  
  // Handle order checkout
  const handleCheckout = (items: CartItem[], total: number) => {
    setCartItems(items);
    setCartTotal(total);
    setPaymentModalOpen(true);
  };
  
  // Handle order completion
  const handleOrderComplete = () => {
    // Clear cart and show success message
    setCartItems([]);
    setCartTotal(0);
    
    toast({
      title: "Order completed",
      description: "The order has been processed successfully.",
    });
  };
  
  // Navigation items
  const staffNavItems = [
    { id: "menu", label: "Menu", icon: ChefHat },
    { id: "orders", label: "Orders", icon: Clock },
  ];
  
  const adminNavItems = [
    ...staffNavItems,
    { id: "reports", label: "Reports", icon: BarChart },
    { id: "settings", label: "Settings", icon: Settings },
  ];
  
  const navItems = userRole === 'admin' ? adminNavItems : staffNavItems;
  
  return (
    <div className="min-h-screen bg-pos flex flex-col">
      <header className="bg-white border-b px-6 py-3 flex items-center justify-between sticky top-0 z-10 shadow-soft">
        <div className="flex items-center space-x-4">
          <Home className="h-6 w-6 text-pos-accent" />
          <h1 className="text-xl font-semibold tracking-tight">Restaurant POS System</h1>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="text-right mr-2">
            <div className="text-sm font-medium">{userRole === 'admin' ? 'ProjectPOS' : 'stafflogin'}</div>
            <div className="text-xs text-pos-text-secondary flex items-center">
              {userRole === 'admin' ? (
                <>
                  <ShieldCheck className="h-3 w-3 mr-1 text-pos-accent" /> Administrator
                </>
              ) : (
                <>
                  <User className="h-3 w-3 mr-1" /> Staff
                </>
              )}
            </div>
          </div>
          <div className={`h-9 w-9 rounded-full flex items-center justify-center ${
            userRole === 'admin' 
              ? 'bg-pos-accent/10 text-pos-accent' 
              : 'bg-pos/70 text-pos-dark'
          }`}>
            {userRole === 'admin' ? (
              <ShieldCheck className="h-5 w-5" />
            ) : (
              <User className="h-5 w-5" />
            )}
          </div>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onLogout}
            className="text-pos-text-secondary hover:text-pos-error hover:bg-pos-error/10"
          >
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </header>
      
      <main className="flex-1 flex">
        <aside className="w-[70px] bg-white border-r flex flex-col items-center py-4">
          <nav className="flex-1 w-full">
            <ul className="space-y-2">
              {navItems.map((item) => (
                <li key={item.id}>
                  <button
                    className={`w-full h-14 flex flex-col items-center justify-center text-xs transition-colors relative ${
                      activeTab === item.id 
                        ? 'text-pos-accent' 
                        : 'text-pos-text-secondary hover:text-pos-dark'
                    }`}
                    onClick={() => setActiveTab(item.id)}
                  >
                    {activeTab === item.id && (
                      <motion.div
                        layoutId="nav-indicator"
                        className="absolute left-0 h-8 w-1 bg-pos-accent rounded-r-full"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.2 }}
                      />
                    )}
                    <item.icon className="h-5 w-5 mb-1" />
                    <span>{item.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </aside>
        
        <div className="flex-1 flex flex-col overflow-hidden">
          <Tabs 
            value={activeTab} 
            onValueChange={setActiveTab}
            className="flex-1 flex flex-col"
          >
            <TabsContent value="menu" className="flex-1 m-0 p-0 outline-none">
              <MenuItems onCheckout={handleCheckout} />
            </TabsContent>
            
            <TabsContent value="orders" className="flex-1 m-0 p-8 outline-none">
              <div className="text-center py-16">
                <h2 className="text-2xl font-medium mb-2">Order History</h2>
                <p className="text-pos-text-secondary">
                  This feature is coming soon. Check back later!
                </p>
              </div>
            </TabsContent>
            
            {userRole === 'admin' && (
              <>
                <TabsContent value="reports" className="flex-1 m-0 p-8 outline-none">
                  <div className="text-center py-16">
                    <h2 className="text-2xl font-medium mb-2">Sales Reports</h2>
                    <p className="text-pos-text-secondary">
                      This feature is coming soon. Check back later!
                    </p>
                  </div>
                </TabsContent>
                
                <TabsContent value="settings" className="flex-1 m-0 p-8 outline-none">
                  <div className="text-center py-16">
                    <h2 className="text-2xl font-medium mb-2">System Settings</h2>
                    <p className="text-pos-text-secondary">
                      This feature is coming soon. Check back later!
                    </p>
                  </div>
                </TabsContent>
              </>
            )}
          </Tabs>
        </div>
        
        <PaymentModal
          open={paymentModalOpen}
          onOpenChange={setPaymentModalOpen}
          cartItems={cartItems}
          total={cartTotal}
          onComplete={handleOrderComplete}
        />
      </main>
    </div>
  );
};

export default Dashboard;
