
-- SQL Database Schema for Restaurant POS System

-- Users Table
CREATE TABLE users (
  user_id SERIAL PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL, -- In real app, store hashed passwords only
  role VARCHAR(20) NOT NULL CHECK (role IN ('admin', 'staff')),
  full_name VARCHAR(100),
  email VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_login TIMESTAMP
);

-- Menu Categories Table
CREATE TABLE categories (
  category_id SERIAL PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE,
  description TEXT,
  image_url VARCHAR(255)
);

-- Menu Items Table
CREATE TABLE menu_items (
  item_id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  category_id INTEGER REFERENCES categories(category_id),
  image_url VARCHAR(255),
  is_available BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Orders Table
CREATE TABLE orders (
  order_id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(user_id),
  table_number INTEGER,
  order_status VARCHAR(20) DEFAULT 'pending' CHECK (order_status IN ('pending', 'completed', 'cancelled')),
  payment_method VARCHAR(20) CHECK (payment_method IN ('cash', 'card')),
  subtotal DECIMAL(10, 2) NOT NULL,
  tax DECIMAL(10, 2) NOT NULL,
  total DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP
);

-- Order Items Table (junction table for orders and menu items)
CREATE TABLE order_items (
  order_item_id SERIAL PRIMARY KEY,
  order_id INTEGER REFERENCES orders(order_id),
  item_id INTEGER REFERENCES menu_items(item_id),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  price_per_unit DECIMAL(10, 2) NOT NULL,
  notes TEXT
);

-- Payments Table
CREATE TABLE payments (
  payment_id SERIAL PRIMARY KEY,
  order_id INTEGER REFERENCES orders(order_id),
  amount DECIMAL(10, 2) NOT NULL,
  payment_method VARCHAR(20) NOT NULL,
  payment_status VARCHAR(20) DEFAULT 'completed',
  transaction_id VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inventory Items Table
CREATE TABLE inventory_items (
  inventory_id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  quantity DECIMAL(10, 2) NOT NULL,
  unit VARCHAR(20) NOT NULL,
  cost_per_unit DECIMAL(10, 2),
  last_restock_date TIMESTAMP,
  minimum_threshold DECIMAL(10, 2)
);

-- Insert Initial Data

-- Categories
INSERT INTO categories (name, description) VALUES 
  ('burgers', 'Delicious beef and veggie burgers'),
  ('pizza', 'Hand-tossed pizzas with fresh toppings'),
  ('drinks', 'Refreshing beverages'),
  ('sides', 'Perfect accompaniments for your meal'),
  ('wraps', 'Fresh wraps with various fillings');

-- Sample menu items
INSERT INTO menu_items (name, price, category_id, image_url) VALUES 
  ('Classic Burger', 8.99, 1, 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'),
  ('Cheese Pizza', 10.99, 2, 'https://images.unsplash.com/photo-1513104890138-7c749659a591?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'),
  ('Pepperoni Pizza', 12.99, 2, 'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'),
  ('Cola', 1.99, 3, 'https://images.unsplash.com/photo-1581098365948-6a5a912b7a49?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'),
  ('French Fries', 3.99, 4, 'https://images.unsplash.com/photo-1526230427044-d092040d48dc?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'),
  ('Double Cheeseburger', 11.99, 1, 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'),
  ('Chicken Wrap', 9.49, 5, 'https://images.unsplash.com/photo-1562967914-608f82629710?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'),
  ('Veggie Wrap', 8.49, 5, 'https://images.unsplash.com/photo-1509722747041-616f39b57569?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80');

-- Sample users
INSERT INTO users (username, password_hash, role, full_name, email) VALUES 
  ('admin', '$2a$10$xVR5hUovBm4ZtMMC8PKnF.QD7E8vzQwmtnT5JBh.lGcH9gUJRj1F6', 'admin', 'Administrator', 'admin@restaurant.com'),
  ('staff1', '$2a$10$PfGJP.4JZmZGKNMvJSXEEueSK.HIMvCLAR24zFhMWcC6NQEm/5ceq', 'staff', 'Staff Member', 'staff@restaurant.com');
