// Menu items data - In a real implementation, this would be loaded from a database
let menuItems = [
  {
    id: 1,
    name: 'Classic Burger',
    price: 8.99,
    category: 'burgers',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'
  },
  {
    id: 2,
    name: 'Cheese Pizza',
    price: 10.99,
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'
  },
  {
    id: 3,
    name: 'Pepperoni Pizza',
    price: 12.99,
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'
  },
  {
    id: 4,
    name: 'Cola',
    price: 1.99,
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1581098365948-6a5a912b7a49?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'
  },
  {
    id: 5,
    name: 'French Fries',
    price: 3.99,
    category: 'sides',
    image: 'https://images.unsplash.com/photo-1526230427044-d092040d48dc?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'
  },
  {
    id: 6,
    name: 'Double Cheeseburger',
    price: 11.99,
    category: 'burgers',
    image: 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'
  },
  {
    id: 7,
    name: 'Chicken Wrap',
    price: 9.49,
    category: 'wraps',
    image: 'https://images.unsplash.com/photo-1562967914-608f82629710?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'
  },
  {
    id: 8,
    name: 'Veggie Wrap',
    price: 8.49,
    category: 'wraps',
    image: 'https://images.unsplash.com/photo-1509722747041-616f39b57569?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80'
  }
];

// Cart data
let cart = [];
let currentUser = null;
let selectedPaymentMethod = 'card';
let cashAmount = 0;
let orderHistory = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
  // Render menu items
  renderMenuItems();
  
  // Update category buttons click event
  const categoryButtons = document.querySelectorAll('.category-btn');
  categoryButtons.forEach(button => {
    button.addEventListener('click', function() {
      categoryButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
      const category = this.getAttribute('data-category');
      filterMenuByCategory(category);
    });
  });

  // Load data from localStorage if available
  loadDataFromStorage();
});

// Save data to local storage (simulating database persistence)
function saveDataToStorage() {
  localStorage.setItem('menuItems', JSON.stringify(menuItems));
  localStorage.setItem('orderHistory', JSON.stringify(orderHistory));
}

// Load data from local storage
function loadDataFromStorage() {
  const storedMenuItems = localStorage.getItem('menuItems');
  const storedOrderHistory = localStorage.getItem('orderHistory');
  
  if (storedMenuItems) {
    menuItems = JSON.parse(storedMenuItems);
  }
  
  if (storedOrderHistory) {
    orderHistory = JSON.parse(storedOrderHistory);
  }
}

// Login function
function login(role) {
  // Simple authentication (in real app would validate against database)
  currentUser = {
    role: role,
    username: role === 'admin' ? 'Admin User' : 'Staff User',
    id: role === 'admin' ? 1 : 2
  };
  
  // Update UI based on role
  document.getElementById('username').textContent = currentUser.username;
  document.getElementById('role').textContent = role === 'admin' ? 'Administrator' : 'Staff';
  
  // Show/hide admin-only elements
  const adminOnlyElements = document.querySelectorAll('.admin-only');
  adminOnlyElements.forEach(element => {
    element.style.display = role === 'admin' ? 'block' : 'none';
  });
  
  // Show dashboard
  document.getElementById('loginScreen').classList.add('hidden');
  document.getElementById('dashboardScreen').classList.remove('hidden');
  
  // Show toast
  showToast(`Logged in as ${role}`);

  // If it's the first login, render order history
  renderOrderHistory();
}

// Logout function
function logout() {
  currentUser = null;
  cart = [];
  
  // Show login screen
  document.getElementById('dashboardScreen').classList.add('hidden');
  document.getElementById('loginScreen').classList.remove('hidden');
  
  // Reset cart
  renderCart();
  
  // Show toast
  showToast('Logged out successfully');
}

// Show a specific tab
function showTab(tabId) {
  // Hide all tabs
  const tabContents = document.querySelectorAll('.tab-content');
  tabContents.forEach(tab => tab.classList.remove('active'));
  
  // Show the selected tab
  const selectedTab = document.getElementById(`${tabId}Tab`);
  if (selectedTab) {
    selectedTab.classList.add('active');
  }
  
  // Update active nav button
  const navButtons = document.querySelectorAll('.nav-btn');
  navButtons.forEach(button => {
    button.classList.remove('active');
    if (button.getAttribute('data-tab') === tabId) {
      button.classList.add('active');
    }
  });
  
  // Special handling for settings tab
  if (tabId === 'settings' && currentUser?.role === 'admin') {
    renderManageMenuItems();
  }
  
  // Special handling for orders tab
  if (tabId === 'orders') {
    renderOrderHistory();
  }
}

// Render menu items
function renderMenuItems(category = 'all') {
  const menuItemsContainer = document.getElementById('menuItems');
  menuItemsContainer.innerHTML = '';
  
  const filteredItems = category === 'all' 
    ? menuItems 
    : menuItems.filter(item => item.category === category);
  
  filteredItems.forEach(item => {
    const menuItemElement = document.createElement('div');
    menuItemElement.className = 'menu-item';
    menuItemElement.innerHTML = `
      <div class="menu-item-image" style="background-image: url('${item.image}')"></div>
      <div class="menu-item-info">
        <div class="menu-item-name">${item.name}</div>
        <div class="menu-item-price">$${item.price.toFixed(2)}</div>
        <button class="menu-item-add" onclick="addToCart(${item.id})">Add to Order</button>
      </div>
    `;
    menuItemsContainer.appendChild(menuItemElement);
  });
}

// Filter menu by category
function filterMenuByCategory(category) {
  renderMenuItems(category);
}

// Add item to cart
function addToCart(itemId) {
  const item = menuItems.find(item => item.id === itemId);
  
  if (item) {
    const existingItem = cart.find(cartItem => cartItem.id === itemId);
    
    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      cart.push({
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: 1
      });
    }
    
    renderCart();
    showToast(`Added ${item.name} to order`);
  }
}

// Remove item from cart
function removeFromCart(itemId) {
  const itemIndex = cart.findIndex(item => item.id === itemId);
  
  if (itemIndex !== -1) {
    if (cart[itemIndex].quantity > 1) {
      cart[itemIndex].quantity -= 1;
    } else {
      cart.splice(itemIndex, 1);
    }
    
    renderCart();
  }
}

// Render cart
function renderCart() {
  const cartItemsContainer = document.getElementById('cartItems');
  cartItemsContainer.innerHTML = '';
  
  if (cart.length === 0) {
    cartItemsContainer.innerHTML = '<p class="empty-cart">Your order is empty</p>';
    document.getElementById('cartTotal').textContent = '$0.00';
    return;
  }
  
  let total = 0;
  
  cart.forEach(item => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;
    
    const cartItemElement = document.createElement('div');
    cartItemElement.className = 'cart-item';
    cartItemElement.innerHTML = `
      <div class="cart-item-name">${item.name}</div>
      <div class="cart-item-quantity">
        <button onclick="removeFromCart(${item.id})">-</button>
        <span>${item.quantity}</span>
        <button onclick="addToCart(${item.id})">+</button>
      </div>
      <div class="cart-item-price">$${itemTotal.toFixed(2)}</div>
    `;
    cartItemsContainer.appendChild(cartItemElement);
  });
  
  document.getElementById('cartTotal').textContent = `$${total.toFixed(2)}`;
}

// Open payment modal
function openPaymentModal() {
  if (cart.length === 0) {
    showToast('Your order is empty');
    return;
  }
  
  // Reset payment method selection
  selectedPaymentMethod = 'card';
  document.getElementById('paymentModal').innerHTML = `
    <div class="modal-content">
      <span class="close-button" onclick="closePaymentModal()">&times;</span>
      <h2>Checkout</h2>
      <div class="payment-summary">
        <h3>Order Summary</h3>
        <div id="paymentItems">
          <!-- Payment items will be dynamically added here -->
        </div>
        <div class="payment-total">
          <span>Total:</span>
          <span id="paymentTotal">$0.00</span>
        </div>
      </div>
      <div class="payment-methods">
        <div class="payment-method active" onclick="selectPaymentMethod('card')">
          <div class="payment-method-icon">💳</div>
          <div>Credit Card</div>
        </div>
        <div class="payment-method" onclick="selectPaymentMethod('cash')">
          <div class="payment-method-icon">💵</div>
          <div>Cash</div>
        </div>
      </div>
      <div id="cashInput" class="hidden">
        <div class="form-group">
          <label for="cashAmount">Cash Amount ($)</label>
          <input type="number" id="cashAmount" min="0" step="0.01" placeholder="Enter cash amount" onchange="updateCashAmount(this.value)">
        </div>
        <div class="change-amount">
          <span class="change-amount-label">Change:</span>
          <span class="change-amount-value" id="changeAmount">$0.00</span>
        </div>
      </div>
      <div class="payment-actions">
        <button class="complete-btn" onclick="completePayment()">Complete Payment</button>
        <button class="cancel-btn" onclick="closePaymentModal()">Cancel</button>
      </div>
    </div>
  `;
  
  renderPaymentItems();
  document.getElementById('paymentModal').classList.remove('hidden');
}

// Helper functions for payment processing
function selectPaymentMethod(method) {
  selectedPaymentMethod = method;
  
  // Update UI
  const methods = document.querySelectorAll('.payment-method');
  methods.forEach(el => el.classList.remove('active'));
  
  if (method === 'card') {
    methods[0].classList.add('active');
    document.getElementById('cashInput').classList.add('hidden');
  } else {
    methods[1].classList.add('active');
    document.getElementById('cashInput').classList.remove('hidden');
    updateChangeAmount();
  }
}

function updateCashAmount(amount) {
  cashAmount = parseFloat(amount);
  updateChangeAmount();
}

function updateChangeAmount() {
  const total = calculateTotal();
  const change = isNaN(cashAmount) ? 0 : Math.max(0, cashAmount - total);
  document.getElementById('changeAmount').textContent = `$${change.toFixed(2)}`;
}

function calculateTotal() {
  return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
}

function renderPaymentItems() {
  const paymentItemsContainer = document.getElementById('paymentItems');
  if (!paymentItemsContainer) return;
  
  paymentItemsContainer.innerHTML = '';
  
  let total = 0;
  
  cart.forEach(item => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;
    
    const paymentItemElement = document.createElement('div');
    paymentItemElement.className = 'payment-item';
    paymentItemElement.innerHTML = `
      <div>${item.name} x ${item.quantity}</div>
      <div>$${itemTotal.toFixed(2)}</div>
    `;
    paymentItemsContainer.appendChild(paymentItemElement);
  });
  
  document.getElementById('paymentTotal').textContent = `$${total.toFixed(2)}`;
}

function closePaymentModal() {
  document.getElementById('paymentModal').classList.add('hidden');
}

function printReceipt() {
  const receiptDate = document.getElementById('receiptDate');
  const receiptItems = document.getElementById('receiptItems').querySelector('tbody');
  const receiptTotal = document.getElementById('receiptTotal');
  
  // Set date
  const now = new Date();
  receiptDate.textContent = now.toLocaleString();
  
  // Clear previous items
  receiptItems.innerHTML = '';
  
  // Add items
  let total = 0;
  
  cart.forEach(item => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;
    
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${item.name}</td>
      <td>${item.quantity}</td>
      <td>$${item.price.toFixed(2)}</td>
      <td>$${itemTotal.toFixed(2)}</td>
    `;
    receiptItems.appendChild(row);
  });
  
  // Set total
  receiptTotal.textContent = `$${total.toFixed(2)}`;
  
  // Print
  const receiptArea = document.getElementById('receiptArea');
  receiptArea.classList.remove('hidden');
  
  const printWindow = window.open('', '_blank');
  printWindow.document.write(`
    <html>
      <head>
        <title>Receipt</title>
        <style>
          body { font-family: 'Courier New', monospace; font-size: 12px; }
          table { width: 100%; border-collapse: collapse; }
          th, td { padding: 5px; text-align: left; }
          hr { border: none; border-top: 1px dashed #000; }
        </style>
      </head>
      <body>
        ${receiptArea.innerHTML}
      </body>
    </html>
  `);
  
  printWindow.document.close();
  printWindow.focus();
  printWindow.print();
  printWindow.close();
  
  receiptArea.classList.add('hidden');
  showToast('Receipt printed');
}

// Complete payment and save order to history
function completePayment() {
  // Validate payment (for cash payment)
  if (selectedPaymentMethod === 'cash') {
    const total = calculateTotal();
    if (isNaN(cashAmount) || cashAmount < total) {
      showToast('Insufficient cash amount');
      return;
    }
  }
  
  // Create order record
  const order = {
    id: Date.now(), // Use timestamp as unique ID
    items: [...cart],
    total: calculateTotal(),
    date: new Date().toISOString(),
    paymentMethod: selectedPaymentMethod,
    user: currentUser ? { id: currentUser.id, name: currentUser.username } : null
  };
  
  // Add to order history
  orderHistory.push(order);
  
  // Save to "database" (localStorage in this demo)
  saveDataToStorage();
  
  // Automatically print receipt
  printReceipt();
  
  // Clear cart
  cart = [];
  renderCart();
  
  // Close modal
  closePaymentModal();
  
  // Show success toast
  showToast(`Order #${order.id} completed successfully using ${selectedPaymentMethod}`);
}

// Render order history
function renderOrderHistory() {
  const orderHistoryContainer = document.getElementById('orderHistory');
  if (!orderHistoryContainer) return;
  
  orderHistoryContainer.innerHTML = '';
  
  if (orderHistory.length === 0) {
    orderHistoryContainer.innerHTML = '<p>No orders found</p>';
    return;
  }
  
  // Sort orders by date (newest first)
  const sortedOrders = [...orderHistory].sort((a, b) => new Date(b.date) - new Date(a.date));
  
  sortedOrders.forEach(order => {
    const date = new Date(order.date);
    const formattedDate = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    
    const orderElement = document.createElement('div');
    orderElement.className = 'order-item';
    orderElement.innerHTML = `
      <div class="order-header">
        <h3>Order #${order.id}</h3>
        <span>${formattedDate}</span>
      </div>
      <div class="order-details">
        <div>Total: $${order.total.toFixed(2)}</div>
        <div>Payment: ${order.paymentMethod}</div>
        <div>Server: ${order.user ? order.user.name : 'Unknown'}</div>
      </div>
      <button onclick="viewOrderDetails(${order.id})">View Details</button>
    `;
    orderHistoryContainer.appendChild(orderElement);
  });
}

// View order details
function viewOrderDetails(orderId) {
  const order = orderHistory.find(o => o.id === orderId);
  if (!order) return;
  
  const date = new Date(order.date);
  const formattedDate = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  
  let itemsHtml = '';
  order.items.forEach(item => {
    itemsHtml += `
      <div class="payment-item">
        <div>${item.name} x ${item.quantity}</div>
        <div>$${(item.price * item.quantity).toFixed(2)}</div>
      </div>
    `;
  });
  
  document.getElementById('paymentModal').innerHTML = `
    <div class="modal-content">
      <span class="close-button" onclick="closePaymentModal()">&times;</span>
      <h2>Order #${order.id} Details</h2>
      <div class="order-meta">
        <div>Date: ${formattedDate}</div>
        <div>Server: ${order.user ? order.user.name : 'Unknown'}</div>
        <div>Payment Method: ${order.paymentMethod}</div>
      </div>
      <div class="payment-summary">
        <h3>Order Items</h3>
        <div>
          ${itemsHtml}
        </div>
        <div class="payment-total">
          <span>Total:</span>
          <span>$${order.total.toFixed(2)}</span>
        </div>
      </div>
      <div class="payment-actions">
        <button class="print-btn" onclick="printOrderReceipt(${order.id})">Print Receipt</button>
        <button class="cancel-btn" onclick="closePaymentModal()">Close</button>
      </div>
    </div>
  `;
  
  document.getElementById('paymentModal').classList.remove('hidden');
}

// Print receipt for past orders
function printOrderReceipt(orderId) {
  const order = orderHistory.find(o => o.id === orderId);
  if (!order) return;
  
  const receiptArea = document.getElementById('receiptArea');
  const receiptDate = document.getElementById('receiptDate');
  const receiptItems = document.getElementById('receiptItems').querySelector('tbody');
  const receiptTotal = document.getElementById('receiptTotal');
  
  // Set date
  const date = new Date(order.date);
  receiptDate.textContent = date.toLocaleString();
  
  // Clear previous items
  receiptItems.innerHTML = '';
  
  // Add items
  order.items.forEach(item => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${item.name}</td>
      <td>${item.quantity}</td>
      <td>$${item.price.toFixed(2)}</td>
      <td>$${(item.price * item.quantity).toFixed(2)}</td>
    `;
    receiptItems.appendChild(row);
  });
  
  // Set total
  receiptTotal.textContent = `$${order.total.toFixed(2)}`;
  
  // Print
  receiptArea.classList.remove('hidden');
  
  const printWindow = window.open('', '_blank');
  printWindow.document.write(`
    <html>
      <head>
        <title>Receipt</title>
        <style>
          body { font-family: 'Courier New', monospace; font-size: 12px; }
          table { width: 100%; border-collapse: collapse; }
          th, td { padding: 5px; text-align: left; }
          hr { border: none; border-top: 1px dashed #000; }
        </style>
      </head>
      <body>
        ${receiptArea.innerHTML}
      </body>
    </html>
  `);
  
  printWindow.document.close();
  printWindow.focus();
  printWindow.print();
  printWindow.close();
  
  receiptArea.classList.add('hidden');
  showToast('Receipt printed');
}

// Show toast notification
function showToast(message) {
  const toast = document.getElementById('toast');
  const toastMessage = document.getElementById('toastMessage');
  
  toastMessage.textContent = message;
  toast.classList.remove('hidden');
  toast.classList.add('show');
  
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 300);
  }, 3000);
}

// Add new menu item (Admin function)
function addMenuItem() {
  if (currentUser?.role !== 'admin') {
    return;
  }
  
  const nameInput = document.getElementById('itemName');
  const priceInput = document.getElementById('itemPrice');
  const categoryInput = document.getElementById('itemCategory');
  const imageInput = document.getElementById('itemImage');
  
  const name = nameInput.value.trim();
  const price = parseFloat(priceInput.value);
  const category = categoryInput.value;
  const image = imageInput.value.trim() || 'https://via.placeholder.com/500?text=Food+Item';
  
  if (!name || isNaN(price)) {
    showToast('Please enter valid item details');
    return;
  }
  
  // Generate new ID
  const newId = Math.max(...menuItems.map(item => item.id), 0) + 1;
  
  // Add new item
  const newItem = {
    id: newId,
    name,
    price,
    category,
    image
  };
  
  menuItems.push(newItem);
  
  // Save to "database" (localStorage in this demo)
  saveDataToStorage();
  
  // Clear form
  nameInput.value = '';
  priceInput.value = '';
  imageInput.value = '';
  
  // Re-render menu and management list
  renderMenuItems();
  renderManageMenuItems();
  
  showToast(`Added ${name} to menu`);
}

// Delete menu item (Admin function)
function deleteMenuItem(itemId) {
  if (currentUser?.role !== 'admin') {
    return;
  }
  
  const itemIndex = menuItems.findIndex(item => item.id === itemId);
  
  if (itemIndex !== -1) {
    const itemName = menuItems[itemIndex].name;
    
    // Confirm deletion
    if (confirm(`Are you sure you want to delete "${itemName}"?`)) {
      menuItems.splice(itemIndex, 1);
      
      // Save to "database" (localStorage in this demo)
      saveDataToStorage();
      
      // Re-render menu and management list
      renderMenuItems();
      renderManageMenuItems();
      
      showToast(`Deleted ${itemName} from menu`);
      
      // Also remove from cart if present
      const cartItemIndex = cart.findIndex(item => item.id === itemId);
      if (cartItemIndex !== -1) {
        cart.splice(cartItemIndex, 1);
        renderCart();
      }
    }
  }
}

// Render menu management items
function renderManageMenuItems() {
  const manageMenuItemsContainer = document.getElementById('manageMenuItems');
  
  if (!manageMenuItemsContainer) {
    return;
  }
  
  manageMenuItemsContainer.innerHTML = '';
  
  menuItems.forEach(item => {
    const manageItemElement = document.createElement('div');
    manageItemElement.className = 'manage-item';
    manageItemElement.innerHTML = `
      <div class="manage-item-info">
        <div class="manage-item-name">${item.name}</div>
        <div class="manage-item-details">
          Price: $${item.price.toFixed(2)} | Category: ${item.category}
        </div>
      </div>
      <div>
        <button class="delete-item-btn" onclick="deleteMenuItem(${item.id})">Delete</button>
      </div>
    `;
    manageMenuItemsContainer.appendChild(manageItemElement);
  });
}
